﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlszewskiJ_TheConversation
{
    // *************************************************************
    // Application:     The Conversation
    // Author:          Olszewski III, James F
    // Description:     An application that has a conversation with the user
    //                  about the internet
    // Date Created:    1/25/2021
    // Date Revised:    1/25/2021
    // *************************************************************
    class Program
    {
        static void Main(string[] args)
        {
            //
            // variables
            //
            string userName;
            string favoriteBrowser;
            string favoriteUse;
            string userResponse;

            int screenTime;
            int myScreenTime = 30;
            int screenDif;

            //
            //      **********************
            //      *   Opening Screen   *
            //      **********************
            //
            // set cursor invisible, background colors, foreground colors, and clear screen
            Console.CursorVisible = false;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            // display an opening screen's information
            Console.WriteLine();
            Console.WriteLine("\t\tThe Internet Questionnaire");
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();

            // begin introductions
            Console.WriteLine("Hello!");
            Console.WriteLine("I am the Internet Questionnaire.");
            Console.WriteLine();
            Console.Write("What is your name, user? ");
            userName = Console.ReadLine();
            Console.WriteLine($"It is nice to meet you {userName}.");

            // request to start the application
            Console.WriteLine();
            Console.Write($"Would you like to start the application, {userName}? (y/n) ");
            userResponse = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();

            if (userResponse == "yes" || userResponse == "y")
            {
                //
                //      ****************************
                //      *     Questions Screen     *
                //      ****************************
                //
                // set cursor invisible, background colors, foreground colors, and clear screen
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tQuestions");
                Console.WriteLine();

                //
                // ask user to start the application
                //
                Console.WriteLine();
                Console.WriteLine("Thank you for starting the application!");
                Console.WriteLine("In this application, I will ask you a handful of questions.");
                Console.WriteLine("Please answer them as best as you can.");
                Console.WriteLine();
                Console.WriteLine("\tPress any key to continue.");
                Console.ReadKey();

                //
                //      ****************************
                //      *     Questions Screens     *
                //      ****************************
                //
                // set cursor invisible, background colors, foreground colors, and clear screen
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tQuestion 1");
                Console.WriteLine();
                Console.Write("What is your favorite internet browser to use? ");
                favoriteBrowser = Console.ReadLine();
                Console.WriteLine();
                if (favoriteBrowser == "google chrome" || favoriteBrowser == "chrome")
                {
                    Console.WriteLine("RIP Flash.");
                }
                else if (favoriteBrowser == "internet explorer" || favoriteBrowser == "explorer")
                {
                    Console.WriteLine("In that case, I apologize if I am moving too fast for you.");
                }
                else if (favoriteBrowser == "mozilla firefox" || favoriteBrowser == "firefox")
                {
                    Console.WriteLine("Not much of a fox anymore is it?");
                }
                else if (favoriteBrowser == "apple safari" || favoriteBrowser == "safari")
                {
                    Console.WriteLine("I don't own any apple products, so I don't know much about it.");
                }
                else // user's response was not valid
                {
                    Console.WriteLine("I am afraid I'm not familiar with that browser.");
                    Console.WriteLine($"You'll have to tell me about it sometime, {userName}.");
                }
                Console.WriteLine();
                Console.WriteLine("\tPress any key to continue.");
                Console.ReadKey();

                // set cursor invisible, background colors, foreground colors, and clear screen
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tQuestion 2");
                Console.WriteLine();
                Console.Write("What do you like to use the internet for? ");
                favoriteUse = Console.ReadLine();
                Console.WriteLine($"So you use the internet for {favoriteUse}? interesting.");
                Console.WriteLine();
                Console.WriteLine("\tPress any key to continue.");
                Console.ReadKey();

                // set cursor invisible, background colors, foreground colors, and clear screen
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tQuestion 3");
                Console.WriteLine();
                Console.Write("How much do you use the internet? (in minutes a day)");
                screenTime = Convert.ToInt32(Console.ReadLine());
                screenDif = screenTime - myScreenTime;
                if (screenDif > 0)
                {
                    Console.WriteLine($"That's {screenDif} mins longer than I use it.");
                }
                else if (screenDif < 0)
                {
                    screenDif = screenDif * -1;
                    Console.WriteLine($"That's {screenDif} mins less than I use it.");
                }
                else
                {
                    Console.WriteLine("Wow! Same!");
                }
                Console.WriteLine();
                Console.WriteLine("\tPress any key to continue.");
                Console.ReadKey();
            }
            //
            //      **********************
            //      *   Closing Screen   *
            //      **********************
            //
            // set cursor invisible, background colors, foreground colors, and clear screen
            Console.CursorVisible = false;
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            // display an opening screen's information
            Console.WriteLine();
            Console.WriteLine("Thanks for stopping by.");
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();
        }
    }
}
